﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JobOpenings.Data.Models
{
    public class SendJobModel
    {
        public int LocationId { get; set; }

        public int DepartmentId { get; set; }
    }
}
